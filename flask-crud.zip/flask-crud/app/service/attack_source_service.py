class AttackSourceService:
    def __init__(self, repository):
        self.repo = repository

    def create(self, source: str):
        return self.repo.create(source)

    def list(self):
        return self.repo.list()

    def get_by_id(self, id: int):
        return self.repo.get_by_id(id)
    
    def update(self, id: int, source: str):
        return self.repo.update(id, source)
    
    def delete(self, id: int):
        return self.repo.delete(id)