import mysql.connector

class AttackSourceRepository:
    def __init__(self, db):
        self.db = db

    def create(self, source: str):
        conn = self.db.get_connection()
        cursor = conn.cursor(dictionary=True)

        cursor.execute(
            "INSERT INTO Attack_Sources (source) VALUES (%s)",
            (source,)
        )

        conn.commit()

        return {
            "id": cursor.lastrowid,
            "source": source
        }

    def list(self):
        conn = self.db.get_connection()
        cursor = conn.cursor(dictionary=True)

        cursor.execute("SELECT * FROM Attack_Sources")
        return cursor.fetchall()
    
    def get_by_id(self, id: int):
        conn = self.db.get_connection()
        cursor = conn.cursor(dictionary=True)

        cursor.execute(
            "SELECT * FROM Attack_Sources WHERE id = %s",
            (id,)
        )

        return cursor.fetchone()
    
    def update(self, id: int, source: str):
        conn = self.db.get_connection()
        cursor = conn.cursor(dictionary=True)

        cursor.execute(
            "UPDATE Attack_Sources SET source = %s WHERE id = %s",
            (source, id)
        )

        if cursor.rowcount == 0:
            return None
        
        conn.commit()

        return {
            "id": id,
            "source": source
        }
    
    def delete(self, id: int):
        conn = self.db.get_connection()
        cursor = conn.cursor(dictionary=True)

        try:
            cursor.execute(
                "DELETE FROM Attack_Sources WHERE id = %s",
                (id,)
            )

            if cursor.rowcount == 0:
                return False

            conn.commit()
            return True

        except mysql.connector.Error as err:
            conn.rollback()

            if err.errno == 1451:
                return "FK"

            raise err