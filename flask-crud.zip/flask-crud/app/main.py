from flask import Flask
from controller.attack_source_controller import attack_source_bp
from controller.attack_type_controller import attack_type_bp
from controller.cyber_threat_controller import cyber_threat_bp
from controller.defense_mechanism_controller import defense_mechanism_bp
from controller.security_vulnerability_controller import security_vulnerability_bp
from controller.target_industry_controller import target_industry_bp

app = Flask(__name__)
app.register_blueprint(attack_source_bp)
app.register_blueprint(attack_type_bp)
app.register_blueprint(cyber_threat_bp)
app.register_blueprint(defense_mechanism_bp)
app.register_blueprint(security_vulnerability_bp)
app.register_blueprint(target_industry_bp)

if __name__ == "__main__":
    app.run(debug=True)