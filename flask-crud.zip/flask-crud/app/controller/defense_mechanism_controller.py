from flask import Blueprint, request, jsonify
from service.defense_mechanism_service import DefenseMechanismService
from repository.defense_mechanism_repository import DefenseMechanismRepository
from database import db

defense_mechanism_bp = Blueprint("defense_mechanisms", __name__, url_prefix="/defense_mechanisms")
service = DefenseMechanismService(DefenseMechanismRepository(db))

@defense_mechanism_bp.post("/")
def create_defense_mechanism():
    data = request.json or {}

    mechanism = data.get("mechanism")

    if not mechanism or not isinstance(mechanism, str):
        return {"error": "Mechanism invalid"}, 400

    return jsonify(
        service.create(mechanism)
    ), 201

@defense_mechanism_bp.get("/")
def list_defense_mechanisms():
    return jsonify(service.list())

@defense_mechanism_bp.get("/<int:id>")
def get_by_id_defense_mechanism(id):
    result = service.get_by_id(id)

    if result is None:
        return {"error": "Not found"}, 404

    return result

@defense_mechanism_bp.put("/<int:id>")
def update_defense_mechanism(id):
    data = request.json or {}

    mechanism = data.get("mechanism")

    if not mechanism or not isinstance(mechanism, str):
        return {"error": "Mechanism invalid"}, 400
    
    result = service.update(id, mechanism)

    if result is None:
        return {"error": "Not found"}, 404
    
    return result

@defense_mechanism_bp.delete("/<int:id>")
def delete_defense_mechanism(id):
    result = service.delete(id)

    if result is False:
        return {"error": "Not found"}, 404

    if result == "FK":
        return {
            "error": "It cannot be deleted"
        }, 409

    return "", 204