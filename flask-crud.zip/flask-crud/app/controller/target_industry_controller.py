from flask import Blueprint, request, jsonify
from service.target_industry_service import TargetIndustryService
from repository.target_industry_repository import TargetIndustryRepository
from database import db

target_industry_bp = Blueprint("target_industries", __name__, url_prefix="/target_industries")
service = TargetIndustryService(TargetIndustryRepository(db))

@target_industry_bp.post("/")
def create_target_industry():
    data = request.json or {}

    industry = data.get("industry")

    if not industry or not isinstance(industry, str):
        return {"error": "Invalid industry"}, 400

    return jsonify(
        service.create(industry)
    ), 201

@target_industry_bp.get("/")
def list_target_industries():
    return jsonify(service.list())

@target_industry_bp.get("/<int:id>")
def get_by_id_target_industry(id):
    result = service.get_by_id(id)

    if result is None:
        return {"error": "Not found"}, 404

    return result

@target_industry_bp.put("/<int:id>")
def update_attack_type(id):
    data = request.json or {}

    industry = data.get("industry")

    if not industry or not isinstance(industry, str):
        return {"error": "Invalid industry"}, 400
    
    result = service.update(id, industry)

    if result is None:
        return {"error": "Not found"}, 404
    
    return result

@target_industry_bp.delete("/<int:id>")
def delete_target_industry(id):
    result = service.delete(id)

    if result is False:
        return {"error": "Not found"}, 404

    if result == "FK":
        return {
            "error": "It cannot be deleted"
        }, 409

    return "", 204