from flask import Blueprint, request, jsonify
from service.attack_type_service import AttackTypeService
from repository.attack_type_repository import AttackTypeRepository
from database import db

attack_type_bp = Blueprint("attack_types", __name__, url_prefix="/attack_types")
service = AttackTypeService(AttackTypeRepository(db))

@attack_type_bp.post("/")
def create_attack_type():
    data = request.json or {}

    type = data.get("type")

    if not type or not isinstance(type, str):
        return {"error": "Invalid type"}, 400

    return jsonify(
        service.create(type)
    ), 201

@attack_type_bp.get("/")
def list_attack_types():
    return jsonify(service.list())

@attack_type_bp.get("/<int:id>")
def get_by_id_attack_type(id):
    result = service.get_by_id(id)

    if result is None:
        return {"error": "Not found"}, 404

    return result

@attack_type_bp.put("/<int:id>")
def update_attack_type(id):
    data = request.json or {}

    type = data.get("type")

    if not type or not isinstance(type, str):
        return {"error": "Invalid type"}, 400
    
    result = service.update(id, type)

    if result is None:
        return {"error": "Not found"}, 404
    
    return result

@attack_type_bp.delete("/<int:id>")
def delete_attack_type(id):
    result = service.delete(id)

    if result is False:
        return {"error": "Not found"}, 404

    if result == "FK":
        return {
            "error": "It cannot be deleted"
        }, 409

    return "", 204