from flask import Blueprint, request, jsonify
from service.attack_source_service import AttackSourceService
from repository.attack_source_repository import AttackSourceRepository
from database import db

attack_source_bp = Blueprint("attack_sources", __name__, url_prefix="/attack_sources")
service = AttackSourceService(AttackSourceRepository(db))

@attack_source_bp.post("/")
def create_attack_source():
    data = request.json or {}

    source = data.get("source")

    if not source or not isinstance(source, str):
        return {"error": "Invalid source"}, 400

    return jsonify(
        service.create(source)
    ), 201

@attack_source_bp.get("/")
def list_attack_sources():
    return jsonify(service.list())

@attack_source_bp.get("/<int:id>")
def get_by_id_attack_source(id):
    result = service.get_by_id(id)

    if result is None:
        return {"error": "Not found"}, 404

    return result

@attack_source_bp.put("/<int:id>")
def update_attack_source(id):
    data = request.json or {}

    source = data.get("source")

    if not source or not isinstance(source, str):
        return {"error": "Invalid source"}, 400
    
    result = service.update(id, source)

    if result is None:
        return {"error": "Not found"}, 404
    
    return result

@attack_source_bp.delete("/<int:id>")
def delete_attack_source(id):
    result = service.delete(id)

    if result is False:
        return {"error": "Not found"}, 404

    if result == "FK":
        return {
            "error": "It cannot be deleted"
        }, 409

    return "", 204